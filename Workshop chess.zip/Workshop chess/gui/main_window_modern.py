﻿"""
现代化主窗口 - 集成现代控制面板
"""
import tkinter as tk
from gui.modern_control_panel import ControlPanel, ModernColors


class MainWindowModern(tk.Tk):
    """现代化主窗口"""
    
    def __init__(self):
        super().__init__()
        
        self.title("象棋 - AlphaZero AI")
        self.geometry("1200x700")
        self.config(bg=ModernColors.BG_LIGHT)
        
        # 主容器
        main_frame = tk.Frame(self, bg=ModernColors.BG_LIGHT)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 左侧：棋盘区域
        left_frame = tk.Frame(main_frame, bg=ModernColors.BG_LIGHT)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=8, pady=8)
        
        board_label = tk.Label(
            left_frame,
            text="棋盘区域",
            bg=ModernColors.BG_CARD,
            fg=ModernColors.TEXT_PRIMARY,
            font=("Segoe UI", 12, "bold"),
            height=20
        )
        board_label.pack(fill=tk.BOTH, expand=True)
        
        # 右侧：控制面板
        right_frame = tk.Frame(main_frame, bg=ModernColors.BG_LIGHT, width=300)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(0, 8), pady=8)
        right_frame.pack_propagate(False)
        
        self.control_panel = ControlPanel(right_frame)
        self.control_panel.pack(fill=tk.BOTH, expand=True)
    
    def run(self):
        """运行应用"""
        self.mainloop()