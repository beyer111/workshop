"""
初级AI：基于规则的贪婪算法
"""
import random
from typing import Tuple, Optional
from game.board import Board
from game.rules import Rules
from game.pieces import PieceType
from utils.evaluator import Evaluator


class BeginnerAI:
    """初级AI：贪婪算法 + 轻量启发"""
    
    def __init__(self, randomness: float = 0.2, stall_threshold: int = 8):
        """
        初始化初级AI
        
        Args:
            randomness: 基础随机比例
            stall_threshold: 连续无吃子的启动激进阈值
        """
        self.base_randomness = randomness
        self.max_randomness = min(0.9, randomness + 0.6)
        self.stall_threshold = max(4, stall_threshold)
        self.aggressive_bonus = 25
    
    def get_move(self, board: Board, is_red: bool) -> Optional[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """获取走法"""
        all_moves = Rules.get_all_legal_moves(board, is_red)
        if not all_moves:
            return None
        
        no_capture_streak = self._no_capture_streak(board)
        effective_randomness = self.base_randomness
        if no_capture_streak >= self.stall_threshold:
            effective_randomness = self.max_randomness
        
        scored_moves = []
        for piece, move in all_moves:
            score = self._score_move(board, piece, move, is_red, no_capture_streak)
            scored_moves.append((score, ((piece.row, piece.col), move)))
        
        scored_moves.sort(key=lambda x: x[0], reverse=True)
        
        if not scored_moves:
            return None
        
        best_move = scored_moves[0][1]
        
        # 若长时间无吃子，鼓励尝试评分接近的激进走法
        if no_capture_streak >= self.stall_threshold:
            aggressive_pool = [
                move for score, move in scored_moves
                if score >= scored_moves[0][0] - self.aggressive_bonus
            ]
            if aggressive_pool:
                best_move = random.choice(aggressive_pool)
        
        if random.random() > effective_randomness:
            return best_move
        
        # 随机 fallback
        piece, move = random.choice(all_moves)
        return ((piece.row, piece.col), move)
    
    def _score_move(self, board: Board, piece, move, is_red: bool, no_capture_streak: int) -> float:
        """为走法打分，加入简单攻防启发"""
        test_board = board.copy()
        from_pos = (piece.row, piece.col)
        test_board.move_piece(from_pos, move)
        
        score = Evaluator.evaluate(test_board, is_red, use_position=False)
        
        target = board.get_piece(*move)
        if target:
            score += target.get_value() * 12
        else:
            score += self._progress_bonus(piece, move, is_red)
        
        if Rules._is_in_check(test_board, not is_red):
            score += 30
        
        score -= self._repeat_move_penalty(board, piece, move)
        
        if no_capture_streak >= self.stall_threshold and not target:
            score -= 15
        
        return score
    
    def _repeat_move_penalty(self, board: Board, piece, move) -> float:
        """若与上一手互相回退，加入惩罚"""
        if not board.move_history:
            return 0.0
        last_from, last_to, _ = board.move_history[-1]
        current_from = (piece.row, piece.col)
        if last_from == move and last_to == current_from:
            return 40.0
        return 0.0
    
    def _progress_bonus(self, piece, move, is_red: bool) -> float:
        """鼓励兵卒推进、中心控制"""
        bonus = 0.0
        row, col = move
        if piece.piece_type == PieceType.PAWN:
            target_row = 9 if is_red else 0
            bonus += max(0, 6 - abs(row - target_row)) * 2
        if 3 <= col <= 5:
            bonus += 4
        if 3 <= row <= 6:
            bonus += 4
        return bonus
    
    def _no_capture_streak(self, board: Board, limit: int = 12) -> int:
        """统计最近若干步无吃子"""
        streak = 0
        for _, _, captured in reversed(board.move_history[-limit:]):
            if captured:
                break
            streak += 1
        return streak

