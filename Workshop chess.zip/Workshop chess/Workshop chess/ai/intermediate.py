"""
中级AI：Minimax + Alpha-Beta + 轻量迭代加深
"""
import time
from typing import Tuple, Optional, List, Dict
from game.board import Board
from game.rules import Rules
from utils.evaluator import Evaluator
from game.pieces import PieceType


class IntermediateAI:
    """
    改进版中级AI：
    - 使用带时间限制的迭代加深（最大深度 <= depth）
    - 简单走法排序（吃子优先、逼近将优先）
    - 无历史表和复杂启发，计算量介于 beginner 与 advanced 之间
    """
    
    def __init__(self, depth: int = 4, time_limit: float = 1.8):
        self.max_depth = max(1, depth)
        self.time_limit = time_limit
        self._start_time = 0.0
        self._best_move: Optional[Tuple[Tuple[int, int], Tuple[int, int]]] = None
        self.repetition_limit = 3
        self.no_capture_threshold = 10
    
    def get_move(self, board: Board, is_red: bool) -> Optional[Tuple[Tuple[int, int], Tuple[int, int]]]:
        all_moves = Rules.get_all_legal_moves(board, is_red)
        if not all_moves:
            return None
        
        self._start_time = time.time()
        no_capture_streak = self._no_capture_streak(board)
        ordered_moves = self._order_moves(board, all_moves, is_red, no_capture_streak)
        self._best_move = None
        root_history: Dict[int, int] = {}
        
        for depth in range(1, self.max_depth + 1):
            if self._time_exceeded():
                break
            
            current_best = None
            current_score = float('-inf')
            
            for piece, move in ordered_moves:
                if self._time_exceeded():
                    break
                
                test_board = board.copy()
                from_pos = (piece.row, piece.col)
                test_board.move_piece(from_pos, move)
                
                score = self._minimax(
                    test_board,
                    depth - 1,
                    not is_red,
                    float('-inf'),
                    float('inf'),
                    is_red,
                    root_history
                )
                
                if score > current_score:
                    current_score = score
                    current_best = (from_pos, move)
            
            if current_best:
                self._best_move = current_best
                ordered_moves = self._promote_move(ordered_moves, current_best)
        
        if self._best_move:
            return self._best_move
        
        # 超时或异常时返回第一个合法走法
        piece, move = ordered_moves[0]
        return ((piece.row, piece.col), move)
    
    def _minimax(self, board: Board, depth: int, is_red: bool, 
                 alpha: float, beta: float, maximizing_player: bool,
                 history: Dict[int, int]) -> float:
        signature = self._board_signature(board, is_red)
        visits = history.get(signature, 0)
        if visits >= self.repetition_limit:
            return 0.0
        history[signature] = visits + 1
        
        if self._time_exceeded():
            value = Evaluator.evaluate(board, maximizing_player, use_position=True)
            history[signature] -= 1
            if history[signature] == 0:
                del history[signature]
            return value
        
        if depth == 0:
            value = Evaluator.evaluate(board, maximizing_player, use_position=True)
            history[signature] -= 1
            if history[signature] == 0:
                del history[signature]
            return value
        
        if Rules.is_checkmate(board, is_red):
            if is_red == maximizing_player:
                value = float('-inf')
            else:
                value = float('inf')
            history[signature] -= 1
            if history[signature] == 0:
                del history[signature]
            return value
        
        all_moves = Rules.get_all_legal_moves(board, is_red)
        if not all_moves:
            value = Evaluator.evaluate(board, maximizing_player, use_position=True)
            history[signature] -= 1
            if history[signature] == 0:
                del history[signature]
            return value
        
        no_capture_streak = self._no_capture_streak(board)
        ordered_moves = self._order_moves(board, all_moves, is_red, no_capture_streak)
        
        if is_red == maximizing_player:
            value = float('-inf')
            for piece, move in ordered_moves:
                if self._time_exceeded():
                    break
                
                test_board = board.copy()
                from_pos = (piece.row, piece.col)
                test_board.move_piece(from_pos, move)
                
                score = self._minimax(test_board, depth - 1, not is_red, 
                                     alpha, beta, maximizing_player, history)
                value = max(value, score)
                alpha = max(alpha, score)
                
                if beta <= alpha:
                    break
            
            history[signature] -= 1
            if history[signature] == 0:
                del history[signature]
            return value
        else:
            value = float('inf')
            for piece, move in ordered_moves:
                if self._time_exceeded():
                    break
                
                test_board = board.copy()
                from_pos = (piece.row, piece.col)
                test_board.move_piece(from_pos, move)
                
                score = self._minimax(test_board, depth - 1, not is_red, 
                                     alpha, beta, maximizing_player, history)
                value = min(value, score)
                beta = min(beta, score)
                
                if beta <= alpha:
                    break
            
            history[signature] -= 1
            if history[signature] == 0:
                del history[signature]
            return value
    
    def _order_moves(self, board: Board, moves: List[Tuple], is_red: bool,
                     no_capture_streak: int = 0) -> List[Tuple]:
        """
        简单走法排序：优先吃子和靠近敌方将的位置
        """
        scored_moves = []
        enemy_king_pos = self._find_king(board, not is_red)
        
        for piece, move in moves:
            target = board.get_piece(*move)
            capture_value = 0
            if target and target.is_red != piece.is_red:
                capture_value = target.get_value()
            
            king_distance = 0
            if enemy_king_pos:
                king_distance = abs(move[0] - enemy_king_pos[0]) + abs(move[1] - enemy_king_pos[1])
            
            score = capture_value - 0.1 * king_distance
            
            score -= self._repeat_move_penalty(board, piece, move)
            
            if no_capture_streak >= self.no_capture_threshold:
                if target:
                    score += target.get_value() * 2
                else:
                    score -= 0.5
            
            scored_moves.append((score, piece, move))
        
        scored_moves.sort(key=lambda x: x[0], reverse=True)
        return [(piece, move) for _, piece, move in scored_moves]
    
    def _promote_move(self, moves: List[Tuple], best_move: Tuple[Tuple[int, int], Tuple[int, int]]) -> List[Tuple]:
        """将上一轮搜索的最佳走法移到列表前面（PV move ordering）"""
        from_pos, to_pos = best_move
        for idx, (piece, move) in enumerate(moves):
            if (piece.row, piece.col) == from_pos and move == to_pos:
                moves.insert(0, moves.pop(idx))
                break
        return moves
    
    def _find_king(self, board: Board, is_red: bool):
        """找到指定阵营将的位置（用于简单排序）"""
        for row in range(Board.ROWS):
            for col in range(Board.COLS):
                piece = board.get_piece(row, col)
                if piece and piece.is_red == is_red and piece.piece_type == PieceType.KING:
                    return (row, col)
        return None
    
    def _time_exceeded(self) -> bool:
        """检查是否超过时间限制"""
        if self.time_limit <= 0:
            return False
        return (time.time() - self._start_time) >= self.time_limit
    
    def _board_signature(self, board: Board, is_red_turn: bool) -> int:
        """为当前局面生成简单哈希"""
        signature = [is_red_turn]
        for piece in board.pieces:
            signature.append((piece.piece_type.value, piece.is_red, piece.row, piece.col))
        return hash(tuple(signature))
    
    def _no_capture_streak(self, board: Board, limit: int = 16) -> int:
        """统计最近的无吃子步数"""
        streak = 0
        for _, _, captured in reversed(board.move_history[-limit:]):
            if captured:
                break
            streak += 1
        return streak
    
    def _repeat_move_penalty(self, board: Board, piece, move) -> float:
        """若形成往返走法，给予惩罚"""
        if not board.move_history:
            return 0.0
        last_from, last_to, _ = board.move_history[-1]
        current_from = (piece.row, piece.col)
        if last_from == move and last_to == current_from:
            return 5.0
        return 0.0

