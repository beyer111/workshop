"""
控制面板组件
"""
import tkinter as tk
from tkinter import ttk
from typing import Optional, Callable


class ControlPanel(tk.Frame):
    """控制面板"""

    # 颜色配置
    BG_COLOR = '#F0F0F0'
    FRAME_BG_COLOR = '#FFFFFF'
    FRAME_FG_COLOR = '#333333'
    BUTTON_BG_COLOR = '#4CAF50'
    BUTTON_FG_COLOR = '#FFFFFF'
    BUTTON_HOVER_COLOR = '#45A049'

    def __init__(self, parent, *args, **kwargs):
        """初始化控制面板"""
        super().__init__(parent, *args, **kwargs)

        self.configure(bg=self.BG_COLOR)

        self.on_mode_change: Optional[Callable] = None
        self.on_difficulty_change: Optional[Callable] = None
        self.on_start_game: Optional[Callable] = None
        self.on_new_game: Optional[Callable] = None
        self.on_undo: Optional[Callable] = None
        self.on_exit: Optional[Callable] = None
        self.on_speed_mode_change: Optional[Callable[[bool], None]] = None

        self._create_widgets()

    def _create_widgets(self):
        """创建控件"""
        # 模式选择
        mode_frame = tk.LabelFrame(self, text="🎮 游戏模式", padx=15, pady=10)
        mode_frame.pack(fill=tk.X, padx=5, pady=8)
        mode_frame.configure(bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                           font=('Arial', 10, 'bold'))

        self.mode_var = tk.StringVar(value="human_vs_ai")
        tk.Radiobutton(mode_frame, text="👤 人机对战", variable=self.mode_var,
                      value="human_vs_ai", command=self._on_mode_change,
                      bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                      font=('Arial', 9), selectcolor='#E8F5E8').pack(anchor=tk.W, pady=2)
        tk.Radiobutton(mode_frame, text="🤖 AI观摩", variable=self.mode_var,
                      value="ai_vs_ai", command=self._on_mode_change,
                      bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                      font=('Arial', 9), selectcolor='#E8F5E8').pack(anchor=tk.W, pady=2)

        # 难度选择
        difficulty_frame = tk.LabelFrame(self, text="⚡ AI难度设置", padx=15, pady=10)
        difficulty_frame.pack(fill=tk.X, padx=5, pady=8)
        difficulty_frame.configure(bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                                 font=('Arial', 10, 'bold'))

        # 红方选择
        red_frame = tk.Frame(difficulty_frame, bg=self.FRAME_BG_COLOR)
        red_frame.pack(fill=tk.X, pady=5)
        tk.Label(red_frame, text="🔴 红方:", bg=self.FRAME_BG_COLOR, fg='#DC143C',
                font=('Arial', 9, 'bold')).pack(side=tk.LEFT)
        self.red_var = tk.StringVar(value="human")
        red_combo = ttk.Combobox(red_frame, textvariable=self.red_var,
                                values=["human", "beginner", "intermediate", "advanced"],
                                state="readonly", width=14, font=('Arial', 9))
        red_combo.pack(side=tk.LEFT, padx=8)
        red_combo.bind("<<ComboboxSelected>>", self._on_difficulty_change)

        # 黑方选择
        black_frame = tk.Frame(difficulty_frame, bg=self.FRAME_BG_COLOR)
        black_frame.pack(fill=tk.X, pady=5)
        tk.Label(black_frame, text="⚫ 黑方:", bg=self.FRAME_BG_COLOR, fg='#2F4F4F',
                font=('Arial', 9, 'bold')).pack(side=tk.LEFT)
        self.black_var = tk.StringVar(value="intermediate")
        black_combo = ttk.Combobox(black_frame, textvariable=self.black_var,
                                  values=["human", "beginner", "intermediate", "advanced"],
                                  state="readonly", width=14, font=('Arial', 9))
        black_combo.pack(side=tk.LEFT, padx=8)
        black_combo.bind("<<ComboboxSelected>>", self._on_difficulty_change)

        # 游戏控制按钮
        control_frame = tk.LabelFrame(self, text="🎯 游戏控制", padx=15, pady=10)
        control_frame.pack(fill=tk.X, padx=5, pady=8)
        control_frame.configure(bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                              font=('Arial', 10, 'bold'))

        # 创建按钮样式
        button_style = {
            'bg': self.BUTTON_BG_COLOR,
            'fg': self.BUTTON_FG_COLOR,
            'font': ('Arial', 9, 'bold'),
            'relief': 'raised',
            'bd': 2,
            'padx': 10,
            'pady': 5,
            'activebackground': self.BUTTON_HOVER_COLOR,
            'activeforeground': self.BUTTON_FG_COLOR,
            'cursor': 'hand2'
        }

        # 按钮网格布局
        button_grid = tk.Frame(control_frame, bg=self.FRAME_BG_COLOR)
        button_grid.pack(fill=tk.X, pady=5)

        # 第一行按钮
        row1 = tk.Frame(button_grid, bg=self.FRAME_BG_COLOR)
        row1.pack(fill=tk.X, pady=3)

        start_btn = tk.Button(row1, text="▶️ 开始游戏", command=self._on_start_game, **button_style, width=12)
        start_btn.pack(side=tk.LEFT, padx=5)

        new_btn = tk.Button(row1, text="🔄 新游戏", command=self._on_new_game, **button_style, width=12)
        new_btn.pack(side=tk.LEFT, padx=5)

        # 第二行按钮
        row2 = tk.Frame(button_grid, bg=self.FRAME_BG_COLOR)
        row2.pack(fill=tk.X, pady=3)

        undo_btn = tk.Button(row2, text="↩️ 悔棋", command=self._on_undo, **button_style, width=12)
        undo_btn.pack(side=tk.LEFT, padx=5)

        exit_btn_style = button_style.copy()
        exit_btn_style['bg'] = '#F44336'
        exit_btn_style['activebackground'] = '#D32F2F'
        exit_btn = tk.Button(row2, text="🚪 退出", command=self._on_exit, **exit_btn_style, width=12)
        exit_btn.pack(side=tk.LEFT, padx=5)

        # 加速模式
        speed_frame = tk.LabelFrame(self, text="⚡ 加速模式", padx=15, pady=10)
        speed_frame.pack(fill=tk.X, padx=5, pady=8)
        speed_frame.configure(bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                            font=('Arial', 10, 'bold'))
        self.speed_mode_var = tk.BooleanVar(value=False)
        tk.Checkbutton(speed_frame, text="🚀 启用加速（AI使用快速模式）",
                       variable=self.speed_mode_var, command=self._on_speed_mode_change,
                       bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                       font=('Arial', 9), selectcolor='#E8F5E8',
                       activebackground=self.FRAME_BG_COLOR,
                       activeforeground=self.FRAME_FG_COLOR).pack(anchor=tk.W, pady=3)

        # 信息显示
        info_frame = tk.LabelFrame(self, text="📊 游戏信息", padx=15, pady=10)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=8)
        info_frame.configure(bg=self.FRAME_BG_COLOR, fg=self.FRAME_FG_COLOR,
                           font=('Arial', 10, 'bold'))

        # 信息文本框样式
        text_style = {
            'bg': '#FFFFFF',
            'fg': '#333333',
            'font': ('Consolas', 9),
            'relief': 'solid',
            'bd': 1,
            'padx': 8,
            'pady': 5,
            'wrap': tk.WORD,
            'height': 10,
            'width': 30
        }

        text_frame = tk.Frame(info_frame, bg=self.FRAME_BG_COLOR)
        text_frame.pack(fill=tk.BOTH, expand=True, pady=3)

        self.info_text = tk.Text(text_frame, **text_style)
        self.info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # 自定义滚动条样式
        scrollbar_style = {
            'bg': self.FRAME_BG_COLOR,
            'troughcolor': '#E0E0E0',
            'activebackground': '#A0A0A0',
            'width': 15
        }
        scrollbar = tk.Scrollbar(text_frame, command=self.info_text.yview, **scrollbar_style)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.info_text.config(yscrollcommand=scrollbar.set)

    def _on_mode_change(self):
        """模式改变回调"""
        if self.on_mode_change:
            self.on_mode_change(self.mode_var.get())

    def _on_start_game(self):
        """开始游戏回调"""
        if self.on_start_game:
            self.on_start_game()

    def _on_new_game(self):
        """新游戏回调"""
        if self.on_new_game:
            self.on_new_game()

    def _on_undo(self):
        """悔棋回调"""
        if self.on_undo:
            self.on_undo()

    def _on_exit(self):
        """退出回调"""
        if self.on_exit:
            self.on_exit()

    def _on_speed_mode_change(self):
        """加速模式切换"""
        if self.on_speed_mode_change:
            self.on_speed_mode_change(self.speed_mode_var.get())

    def is_speed_mode(self) -> bool:
        """是否启用加速模式"""
        return self.speed_mode_var.get()

    def _on_difficulty_change(self, event=None):
        """难度改变回调"""
        if self.on_difficulty_change:
            self.on_difficulty_change(
                self.red_var.get(),
                self.black_var.get()
            )

    def update_info(self, text: str):
        """更新信息显示"""
        self.info_text.insert(tk.END, text + "\n")
        self.info_text.see(tk.END)

    def clear_info(self):
        """清空信息显示"""
        self.info_text.delete(1.0, tk.END)

    def get_mode(self) -> str:
        """获取当前模式"""
        return self.mode_var.get()

    def get_red_player(self) -> str:
        """获取红方玩家类型"""
        return self.red_var.get()

    def get_black_player(self) -> str:
        """获取黑方玩家类型"""
        return self.black_var.get()