"""
棋盘组件 - 集成ChineseChess AlphaZero项目的UI资源
"""
import tkinter as tk
from PIL import Image, ImageTk
import os
from typing import Optional, Callable, Tuple
from game.board import Board
from game.pieces import Piece

# 棋子图片风格配置
PIECE_STYLE = 'WOOD'  # 可以是 'WOOD', 'DELICATE', 'POLISH'


class BoardWidget(tk.Canvas):
    """棋盘画布组件"""
    
    ROWS = 10
    COLS = 9
    CELL_SIZE = 60
    BOARD_WIDTH = COLS * CELL_SIZE
    BOARD_HEIGHT = ROWS * CELL_SIZE

    # 颜色配置
    BOARD_BG_COLOR = '#F4D03F'  # 木质棋盘色
    LINE_COLOR = '#8B4513'      # 棋盘线条颜色
    RIVER_COLOR = '#654321'     # 楚河汉界颜色
    HIGHLIGHT_SELECTED = '#87CEEB'  # 选中高亮
    HIGHLIGHT_MOVE = '#FFD700'    # 上一步高亮
    LEGAL_MOVE_DOT = '#90EE90'    # 合法走法提示

    # 传统棋子颜色配置（基于真实中国象棋）
    RED_PIECE_COLOR = '#DC143C'   # 传统红色（略带橙红）
    BLACK_PIECE_COLOR = '#2C2C2C' # 传统黑色（深黑色）
    RED_TEXT_COLOR = '#FFFF00'     # 红方文字颜色（金黄色）
    BLACK_TEXT_COLOR = '#FFFFFF'   # 黑方文字颜色（白色）
    PIECE_OUTLINE_COLOR = '#FFFFFF' # 棋子边框颜色
    
    def __init__(self, parent, piece_style='WOOD', *args, **kwargs):
        """初始化棋盘组件"""
        width = self.COLS * self.CELL_SIZE
        height = self.ROWS * self.CELL_SIZE
        super().__init__(parent, width=width, height=height, bg='black', *args, **kwargs)

        # 设置棋子样式
        global PIECE_STYLE
        PIECE_STYLE = piece_style

        self.board: Optional[Board] = None
        self.selected_piece: Optional[Piece] = None
        self.legal_moves: list = []
        self.last_move: Optional[Tuple[Tuple[int, int], Tuple[int, int]]] = None
        self.on_move_callback: Optional[Callable] = None
        self.board_image = None
        self.board_photo = None

        # 棋子图片缓存
        self.piece_images = {}
        self.piece_photos = {}

        self.bind("<Button-1>", self._on_click)

        # 加载棋盘图片背景
        self._load_board_image()

        # 加载棋子图片
        self._load_piece_images()

        # 绘制棋盘
        self._draw_board()
    
    def _load_board_image(self):
        """加载棋盘背景图片 - 支持ChineseChess AlphaZero的背景样式"""
        try:
            # 获取图片路径
            current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

            # 尝试加载ChineseChess AlphaZero的背景图片
            image_path = os.path.join(current_dir, 'assets', 'images', f'{PIECE_STYLE}.GIF')

            if not os.path.exists(image_path):
                # 回退到原来的棋盘图片
                image_path = os.path.join(current_dir, 'assets', 'chess_board.jpg')

            if os.path.exists(image_path):
                # 加载并缩放图片
                self.board_image = Image.open(image_path)
                # 缩放图片以适应棋盘尺寸
                self.board_image = self.board_image.resize(
                    (self.BOARD_WIDTH, self.BOARD_HEIGHT),
                    Image.Resampling.LANCZOS
                )
                self.board_photo = ImageTk.PhotoImage(self.board_image)
                print(f"Successfully loaded board background: {image_path}")
            else:
                print(f"Board image not found: {image_path}")
        except Exception as e:
            print(f"Failed to load board image: {e}")

    def _load_piece_images(self):
        """加载所有棋子图片 - 支持ChineseChess AlphaZero的棋子样式"""
        try:
            # 获取图片目录
            current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

            # 首先尝试ChineseChess AlphaZero的图片
            alpha_zero_dir = os.path.join(current_dir, 'assets', 'images', PIECE_STYLE)

            # 备用：原来的棋子图片目录
            legacy_pieces_dir = os.path.join(current_dir, 'assets', 'pieces')

            # ChineseChess AlphaZero的棋子图片映射 (使用其文件命名规则)
            alpha_zero_mapping = {
                # 红方棋子 (R开头)
                ('red', 'ROOK'): ['RR.GIF', 'RRS.GIF'],      # 车
                ('red', 'CANNON'): ['RC.GIF', 'RCS.GIF'],    # 炮
                ('red', 'HORSE'): ['RN.GIF', 'RNS.GIF'],     # 马
                ('red', 'KING'): ['RK.GIF', 'RKS.GIF'],      # 帅
                ('red', 'ELEPHANT'): ['RB.GIF', 'RBS.GIF'],  # 相
                ('red', 'ADVISOR'): ['RA.GIF', 'RAS.GIF'],   # 仕
                ('red', 'PAWN'): ['RP.GIF', 'RPS.GIF'],      # 兵

                # 黑方棋子 (B开头)
                ('black', 'ROOK'): ['BR.GIF', 'BRS.GIF'],    # 车
                ('black', 'CANNON'): ['BC.GIF', 'BCS.GIF'],  # 炮
                ('black', 'HORSE'): ['BN.GIF', 'BNS.GIF'],   # 马
                ('black', 'KING'): ['BK.GIF', 'BKS.GIF'],    # 将
                ('black', 'ELEPHANT'): ['BB.GIF', 'BBS.GIF'], # 象
                ('black', 'ADVISOR'): ['BA.GIF', 'BAS.GIF'],  # 士
                ('black', 'PAWN'): ['BP.GIF', 'BPS.GIF'],    # 卒
            }

            # 原来的棋子图片映射（备用）
            legacy_mapping = {
                # 红方棋子
                'red_shuai': ('red', 'KING'),
                'red_shi': ('red', 'ADVISOR'),
                'red_xiang': ('red', 'ELEPHANT'),
                'red_ma': ('red', 'HORSE'),
                'red_che': ('red', 'ROOK'),
                'red_pao': ('red', 'CANNON'),
                'red_bing': ('red', 'PAWN'),
                # 黑方棋子
                'black_jiang': ('black', 'KING'),
                'black_shi': ('black', 'ADVISOR'),
                'black_xiang': ('black', 'ELEPHANT'),
                'black_ma': ('black', 'HORSE'),
                'black_che': ('black', 'ROOK'),
                'black_pao': ('black', 'CANNON'),
                'black_zu': ('black', 'PAWN'),
            }

            # 首先加载ChineseChess AlphaZero的图片
            loaded_any = False
            for (color, piece_type), filenames in alpha_zero_mapping.items():
                normal_file, selected_file = filenames

                # 加载普通状态图片
                normal_path = os.path.join(alpha_zero_dir, normal_file)
                if os.path.exists(normal_path):
                    try:
                        # 加载并缩放图片
                        image = Image.open(normal_path)
                        piece_size = int(self.CELL_SIZE * 0.9)
                        image = image.resize((piece_size, piece_size), Image.Resampling.LANCZOS)
                        photo = ImageTk.PhotoImage(image)

                        # 缓存图片
                        key = (color, piece_type)
                        self.piece_images[key] = image
                        self.piece_photos[key] = photo
                        loaded_any = True
                        print(f"Successfully loaded piece image: {color} {piece_type}")
                    except Exception as e:
                        print(f"Failed to load piece image {normal_path}: {e}")
                else:
                    print(f"Piece image not found: {normal_path}")

            # 如果没有加载到任何ChineseChess图片，使用原来的图片
            if not loaded_any:
                print("ChineseChess AlphaZero images not found, using legacy images...")
                for filename, (color, piece_type) in legacy_mapping.items():
                    image_path = os.path.join(legacy_pieces_dir, f'{filename}.png')
                    if os.path.exists(image_path):
                        try:
                            # 加载并缩放图片
                            image = Image.open(image_path)
                            piece_size = int(self.CELL_SIZE * 0.9)
                            image = image.resize((piece_size, piece_size), Image.Resampling.LANCZOS)
                            photo = ImageTk.PhotoImage(image)

                            # 缓存图片
                            key = (color, piece_type)
                            self.piece_images[key] = image
                            self.piece_photos[key] = photo
                            print(f"Successfully loaded legacy piece image: {filename}")
                        except Exception as e:
                            print(f"Failed to load legacy piece image {image_path}: {e}")

        except Exception as e:
            print(f"Failed to load piece images: {e}")

    def set_board(self, board: Board):
        """设置棋盘"""
        self.board = board
        self._draw_board()
    
    def set_on_move(self, callback: Callable):
        """设置走子回调函数"""
        self.on_move_callback = callback
    
    def set_selected_piece(self, piece: Optional[Piece], legal_moves: list = None):
        """设置选中的棋子"""
        self.selected_piece = piece
        self.legal_moves = legal_moves or []
        self._redraw()
    
    def set_last_move(self, from_pos: Optional[Tuple[int, int]],
                     to_pos: Optional[Tuple[int, int]]):
        """设置上一步走子"""
        if from_pos and to_pos:
            self.last_move = (from_pos, to_pos)
        else:
            self.last_move = None
        self._draw_board()

    def set_piece_style(self, style: str):
        """动态切换棋子样式"""
        global PIECE_STYLE
        if style in ['WOOD', 'DELICATE', 'POLISH']:
            PIECE_STYLE = style
            # 重新加载图片
            self._load_board_image()
            self._load_piece_images()
            # 重新绘制棋盘
            self._draw_board()
            print(f"Piece style switched to: {style}")
        else:
            print(f"Unsupported piece style: {style}, supported styles: WOOD, DELICATE, POLISH")

    def get_available_styles(self) -> list:
        """获取可用的棋子样式列表"""
        current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        images_dir = os.path.join(current_dir, 'assets', 'images')
        available_styles = []

        for style in ['WOOD', 'DELICATE', 'POLISH']:
            style_dir = os.path.join(images_dir, style)
            if os.path.exists(style_dir):
                # 检查是否有棋子图片
                if any(f.endswith('.GIF') for f in os.listdir(style_dir)):
                    available_styles.append(style)

        return available_styles

    def _draw_board(self):
        """绘制整个棋盘"""
        # 清除所有内容
        self.delete("all")

        # 绘制背景图片
        if self.board_photo:
            self.create_image(0, 0, anchor='nw', image=self.board_photo, tags="board_bg")
        else:
            # 如果没有图片，使用原来的网格绘制方法
            self._draw_grid()

        # 如果有棋盘，绘制棋子
        if self.board:
            self._draw_pieces()

    def _draw_pieces(self):
        """绘制所有棋子"""
        # 绘制上一步走子标记
        if self.last_move:
            from_pos, to_pos = self.last_move
            self._draw_cell_highlight(from_pos[0], from_pos[1], self.HIGHLIGHT_MOVE, "last_move")
            self._draw_cell_highlight(to_pos[0], to_pos[1], self.HIGHLIGHT_MOVE, "last_move")

        # 绘制选中棋子高亮
        if self.selected_piece:
            self._draw_cell_highlight(self.selected_piece.row, self.selected_piece.col,
                                     self.HIGHLIGHT_SELECTED, "highlight")

        # 绘制合法走法提示
        for row, col in self.legal_moves:
            self._draw_legal_move_dot(row, col)

        # 绘制棋子
        for row in range(self.ROWS):
            for col in range(self.COLS):
                piece = self.board.get_piece(row, col)
                if piece:
                    self._draw_piece(piece)
    
    def _draw_grid(self):
        """绘制棋盘网格"""
        self.delete("grid")

        # 绘制横线
        for row in range(self.ROWS):
            y = row * self.CELL_SIZE
            self.create_line(0, y, self.COLS * self.CELL_SIZE, y,
                           fill=self.LINE_COLOR, width=2, tags="grid")

        # 绘制竖线
        for col in range(self.COLS):
            x = col * self.CELL_SIZE
            # 上半部分竖线
            self.create_line(x, 0, x, 4 * self.CELL_SIZE,
                           fill=self.LINE_COLOR, width=2, tags="grid")
            # 下半部分竖线
            self.create_line(x, 5 * self.CELL_SIZE, x, self.ROWS * self.CELL_SIZE,
                           fill=self.LINE_COLOR, width=2, tags="grid")

        # 绘制楚河汉界
        river_y1 = 4 * self.CELL_SIZE
        river_y2 = 5 * self.CELL_SIZE
        river_width = self.COLS * self.CELL_SIZE

        # 楚河汉界背景
        self.create_rectangle(0, river_y1, river_width, river_y2,
                            fill='#D2B48C', outline='', tags="grid")

        # 楚河汉界边线
        self.create_line(0, river_y1, river_width, river_y1,
                        fill=self.RIVER_COLOR, width=3, tags="grid")
        self.create_line(0, river_y2, river_width, river_y2,
                        fill=self.RIVER_COLOR, width=3, tags="grid")

        # 绘制"楚河"和"汉界"文字
        chu_x = river_width * 0.25
        han_x = river_width * 0.75
        river_text_y = (river_y1 + river_y2) / 2

        self.create_text(chu_x, river_text_y, text="楚 河",
                        font=('楷体', 16, 'bold'), fill=self.RIVER_COLOR, tags="grid")
        self.create_text(han_x, river_text_y, text="汉 界",
                        font=('楷体', 16, 'bold'), fill=self.RIVER_COLOR, tags="grid")

        # 绘制九宫格斜线
        self._draw_palace_lines()

        # 绘制坐标标识
        self._draw_coordinates()

    def _draw_palace_lines(self):
        """绘制九宫格斜线"""
        # 上方九宫格
        top_palace_left = 3 * self.CELL_SIZE
        top_palace_right = 5 * self.CELL_SIZE
        self.create_line(top_palace_left, 0, top_palace_right, 2 * self.CELL_SIZE,
                        fill=self.LINE_COLOR, width=2, tags="grid")
        self.create_line(top_palace_right, 0, top_palace_left, 2 * self.CELL_SIZE,
                        fill=self.LINE_COLOR, width=2, tags="grid")

        # 下方九宫格
        bottom_palace_left = 3 * self.CELL_SIZE
        bottom_palace_right = 5 * self.CELL_SIZE
        self.create_line(bottom_palace_left, 7 * self.CELL_SIZE, bottom_palace_right, 9 * self.CELL_SIZE,
                        fill=self.LINE_COLOR, width=2, tags="grid")
        self.create_line(bottom_palace_right, 7 * self.CELL_SIZE, bottom_palace_left, 9 * self.CELL_SIZE,
                        fill=self.LINE_COLOR, width=2, tags="grid")

    def _draw_coordinates(self):
        """绘制坐标标识"""
        # 绘制列标识 (1-9)
        for col in range(self.COLS):
            x = col * self.CELL_SIZE + self.CELL_SIZE // 2
            # 顶部列号
            self.create_text(x, -15, text=str(9 - col),
                           font=('Arial', 10, 'bold'), fill=self.LINE_COLOR, tags="grid")
            # 底部列号
            self.create_text(x, self.ROWS * self.CELL_SIZE + 15, text=str(9 - col),
                           font=('Arial', 10, 'bold'), fill=self.LINE_COLOR, tags="grid")

        # 绘制行标识 (1-10)
        for row in range(self.ROWS):
            y = row * self.CELL_SIZE + self.CELL_SIZE // 2
            # 左侧行号
            self.create_text(-15, y, text=str(row + 1),
                           font=('Arial', 10, 'bold'), fill=self.LINE_COLOR, tags="grid")
            # 右侧行号
            self.create_text(self.COLS * self.CELL_SIZE + 15, y, text=str(row + 1),
                           font=('Arial', 10, 'bold'), fill=self.LINE_COLOR, tags="grid")
    
    def _redraw(self):
        """重绘棋盘（保持兼容性）"""
        self._draw_board()
    
    def _draw_cell_highlight(self, row: int, col: int, color: str, tag: str):
        """绘制单元格高亮"""
        x1 = col * self.CELL_SIZE + 3
        y1 = row * self.CELL_SIZE + 3
        x2 = x1 + self.CELL_SIZE - 6
        y2 = y1 + self.CELL_SIZE - 6

        # 为了在图片背景上更明显，使用不透明的颜色并添加边框
        if tag == "highlight":
            # 选中高亮 - 使用蓝色边框
            self.create_rectangle(x1, y1, x2, y2, fill='',
                                outline='#0066CC', width=3, tags=tag)
            # 添加半透明填充效果
            self.create_rectangle(x1+1, y1+1, x2-1, y2-1, fill='#4169E1',
                                outline='', tags=tag, stipple='gray50')
        elif tag == "last_move":
            # 上一步高亮 - 使用黄色边框
            self.create_rectangle(x1, y1, x2, y2, fill='',
                                outline='#FFB300', width=3, tags=tag)
            # 添加半透明填充效果
            self.create_rectangle(x1+1, y1+1, x2-1, y2-1, fill='#FFD700',
                                outline='', tags=tag, stipple='gray50')
        else:
            # 默认高亮
            self.create_rectangle(x1, y1, x2, y2, fill=color,
                                outline='', tags=tag, stipple='gray50')

    def _draw_legal_move_dot(self, row: int, col: int):
        """绘制合法走法提示点"""
        x = col * self.CELL_SIZE + self.CELL_SIZE // 2
        y = row * self.CELL_SIZE + self.CELL_SIZE // 2

        # 检查该位置是否有棋子
        if self.board and self.board.get_piece(row, col):
            # 如果有敌方棋子，绘制红色框表示可以吃子
            x1 = col * self.CELL_SIZE + 4
            y1 = row * self.CELL_SIZE + 4
            x2 = x1 + self.CELL_SIZE - 8
            y2 = y1 + self.CELL_SIZE - 8
            # 使用更明显的红色和更粗的边框
            self.create_rectangle(x1, y1, x2, y2,
                                outline='#CC0000', width=4, tags="legal_move")
            # 添加内部虚线框
            self.create_rectangle(x1+2, y1+2, x2-2, y2-2,
                                outline='', fill='#FF0000', tags="legal_move", stipple='gray50')
        else:
            # 如果是空位，绘制更明显的绿点表示可以移动
            # 外圈白色边框
            self.create_oval(x - 8, y - 8, x + 8, y + 8,
                           fill='', outline='white', width=3, tags="legal_move")
            # 内圈绿色填充
            self.create_oval(x - 6, y - 6, x + 6, y + 6,
                           fill='#00CC00', outline='#006600', width=2,
                           tags="legal_move")
    
    def _draw_piece(self, piece: Piece):
        """绘制图片棋子"""
        row, col = piece.row, piece.col
        x = col * self.CELL_SIZE + self.CELL_SIZE // 2
        y = row * self.CELL_SIZE + self.CELL_SIZE // 2

        # 获取棋子图片
        color = 'red' if piece.is_red else 'black'
        piece_type = piece.piece_type.name
        key = (color, piece_type)

        if key in self.piece_photos:
            # 使用图片棋子
            photo = self.piece_photos[key]
            piece_size = int(self.CELL_SIZE * 0.9)
            x1 = x - piece_size // 2
            y1 = y - piece_size // 2
            x2 = x1 + piece_size
            y2 = y1 + piece_size

            # 绘制轻微阴影
            shadow_offset = 2
            self.create_rectangle(x1 + shadow_offset, y1 + shadow_offset,
                                x2 + shadow_offset, y2 + shadow_offset,
                                fill='gray', outline='', tags="piece", stipple='gray25')

            # 绘制棋子图片
            self.create_image(x, y, image=photo, tags="piece")
        else:
            # 如果图片不存在，使用原来的渲染方式
            self._draw_fallback_piece(piece, x, y)

    def _draw_fallback_piece(self, piece: Piece, x: int, y: int):
        """备用棋子绘制方法（当图片不可用时）"""
        radius = self.CELL_SIZE // 2.5

        # 传统棋子样式配置
        if piece.is_red:
            bg_color = self.RED_PIECE_COLOR
            text_color = self.RED_TEXT_COLOR
            shadow_color = '#8B0000'
        else:
            bg_color = self.BLACK_PIECE_COLOR
            text_color = self.BLACK_TEXT_COLOR
            shadow_color = '#000000'

        # 绘制轻微阴影效果
        shadow_offset = 1
        self.create_oval(x - radius + shadow_offset, y - radius + shadow_offset,
                        x + radius + shadow_offset, y + radius + shadow_offset,
                        fill=shadow_color, outline='', tags="piece", stipple='gray25')

        # 绘制棋子主体
        self.create_oval(x - radius, y - radius, x + radius, y + radius,
                        fill=bg_color, outline=self.PIECE_OUTLINE_COLOR, width=1, tags="piece")

        # 获取棋子显示名称
        piece_name = self._get_piece_display_name(piece)
        font_size = max(14, int(radius * 0.7))

        # 绘制棋子文字
        self.create_text(x, y, text=piece_name, fill=text_color,
                        font=('宋体', font_size, 'bold'), tags="piece")

    def _get_piece_display_name(self, piece: Piece) -> str:
        """获取棋子的传统显示名称"""
        # 根据棋子类型和颜色返回传统名称
        if piece.piece_type.value == '将':
            return '帥' if piece.is_red else '將'
        elif piece.piece_type.value == '士':
            return '仕' if piece.is_red else '士'
        elif piece.piece_type.value == '象':
            return '相' if piece.is_red else '象'
        elif piece.piece_type.value == '马':
            return '傌' if piece.is_red else '馬'
        elif piece.piece_type.value == '车':
            return '車'
        elif piece.piece_type.value == '炮':
            return '炮'
        elif piece.piece_type.value == '兵':
            return '兵' if piece.is_red else '卒'
        else:
            return piece.piece_type.value  # 默认返回原值
    
    def _on_click(self, event):
        """处理鼠标点击"""
        if not self.board or not self.on_move_callback:
            return
        
        col = event.x // self.CELL_SIZE
        row = event.y // self.CELL_SIZE
        
        if not (0 <= row < self.ROWS and 0 <= col < self.COLS):
            return
        
        clicked_piece = self.board.get_piece(row, col)
        
        # 如果点击了合法走法位置
        if self.selected_piece and (row, col) in self.legal_moves:
            from_pos = (self.selected_piece.row, self.selected_piece.col)
            to_pos = (row, col)
            self.on_move_callback(from_pos, to_pos)
            self.set_selected_piece(None)
            return
        
        # 如果点击了棋子，选中它（由主窗口判断是否为当前玩家的棋子）
        if clicked_piece:
            from game.rules import Rules
            legal_moves = Rules.get_legal_moves(self.board, clicked_piece)
            self.set_selected_piece(clicked_piece, legal_moves)
        else:
            self.set_selected_piece(None)

