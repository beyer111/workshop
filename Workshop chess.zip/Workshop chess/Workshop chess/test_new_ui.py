"""
测试新的UI集成
"""
import tkinter as tk
from tkinter import ttk, messagebox
import os

from gui.board_widget import BoardWidget
from game.board import Board


class TestUIApp:
    """测试新UI的简单应用"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🏯 iChess UI 测试 - ChineseChess AlphaZero Integration")
        self.root.geometry("800x650")
        self.root.configure(bg='#F0F0F0')

        self.board = Board()

        self._create_widgets()

    def _create_widgets(self):
        """创建测试界面组件"""
        # 标题
        title_label = tk.Label(
            self.root,
            text="ChineseChess AlphaZero UI 集成测试",
            bg='#F0F0F0', fg='#333333',
            font=('Arial', 16, 'bold')
        )
        title_label.pack(pady=10)

        # 控制面板
        control_frame = tk.Frame(self.root, bg='#F0F0F0')
        control_frame.pack(fill=tk.X, padx=20, pady=5)

        # 样式选择
        style_frame = tk.Frame(control_frame, bg='#F0F0F0')
        style_frame.pack(side=tk.LEFT, padx=10)

        tk.Label(style_frame, text="棋盘样式:", bg='#F0F0F0', fg='#333333',
                font=('Arial', 10)).pack(side=tk.LEFT, padx=(0, 5))

        self.style_var = tk.StringVar(value='WOOD')

        # 获取可用样式
        board_widget_temp = BoardWidget(tk.Frame(), piece_style='WOOD')
        available_styles = board_widget_temp.get_available_styles()

        self.style_combo = ttk.Combobox(
            style_frame,
            textvariable=self.style_var,
            values=available_styles,
            state='readonly',
            width=12
        )
        self.style_combo.pack(side=tk.LEFT)
        self.style_combo.bind('<<ComboboxSelected>>', self._on_style_change)

        # 测试按钮
        button_frame = tk.Frame(control_frame, bg='#F0F0F0')
        button_frame.pack(side=tk.LEFT, padx=20)

        tk.Button(
            button_frame,
            text="测试新棋盘",
            command=self._test_new_board,
            bg='#4CAF50', fg='white',
            font=('Arial', 10, 'bold')
        ).pack(side=tk.LEFT, padx=5)

        tk.Button(
            button_frame,
            text="显示信息",
            command=self._show_info,
            bg='#2196F3', fg='white',
            font=('Arial', 10, 'bold')
        ).pack(side=tk.LEFT, padx=5)

        # 棋盘容器
        board_container = tk.Frame(self.root, bg='#8B4513', relief='solid', bd=3)
        board_container.pack(pady=20)

        # 创建棋盘
        self.board_widget = BoardWidget(board_container, piece_style=self.style_var.get())
        self.board_widget.pack(padx=5, pady=5)
        self.board_widget.set_board(self.board)
        self.board_widget.set_on_move(self._on_move)

        # 状态栏
        self.status_label = tk.Label(
            self.root,
            text="准备就绪 - 请点击棋子进行测试",
            bg='#F0F0F0', fg='#666666',
            font=('Arial', 10),
            relief=tk.SUNKEN,
            anchor=tk.W
        )
        self.status_label.pack(fill=tk.X, side=tk.BOTTOM, padx=20, pady=5)

    def _on_style_change(self, event=None):
        """样式切换处理"""
        new_style = self.style_var.get()

        # 保存当前状态
        selected_piece = self.board_widget.selected_piece
        last_move = self.board_widget.last_move
        legal_moves = self.board_widget.legal_moves

        # 切换样式
        self.board_widget.set_piece_style(new_style)

        # 恢复状态
        self.board_widget.set_board(self.board)
        if selected_piece:
            self.board_widget.set_selected_piece(selected_piece, legal_moves)
        if last_move:
            self.board_widget.set_last_move(last_move[0], last_move[1])

        self.status_label.config(text=f"棋盘样式已切换到: {new_style}")

    def _test_new_board(self):
        """测试新棋盘功能"""
        # 重置棋盘
        self.board = Board()
        self.board_widget.set_board(self.board)

        # 测试走子
        try:
            # 模拟一步简单的走子 (例如：炮移动)
            from game.rules import Rules
            # 找到红方的炮
            for row in range(self.board.ROWS):
                for col in range(self.board.COLS):
                    piece = self.board.get_piece(row, col)
                    if piece and piece.is_red and piece.piece_type.value == '炮':
                        # 获取合法走法
                        legal_moves = Rules.get_legal_moves(self.board, piece)
                        if legal_moves:
                            # 执行第一步合法走法
                            from_pos = (row, col)
                            to_pos = legal_moves[0]

                            # 移动棋子
                            piece.row, piece.col = to_pos[0], to_pos[1]
                            self.board.board[to_pos[0]][to_pos[1]] = piece
                            self.board.board[row][col] = None

                            # 更新显示
                            self.board_widget.set_last_move(from_pos, to_pos)
                            self.board_widget._draw_board()

                            self.status_label.config(
                                text=f"测试成功：红炮从 {from_pos} 移动到 {to_pos}"
                            )
                            return
        except Exception as e:
            self.status_label.config(text=f"测试失败: {e}")

    def _show_info(self):
        """显示集成信息"""
        info_text = f"""
🏯 ChineseChess AlphaZero UI 集成信息

✅ 已完成的功能：
• 复制了ChineseChess AlphaZero的高质量棋子图片
• 支持多种棋子样式：{', '.join(self.board_widget.get_available_styles())}
• 动态样式切换功能
• 兼容原有算法和游戏逻辑

🎨 新增特性：
• 精美的木质棋盘背景
• 专业的中国象棋棋子图标
• 可切换的棋子风格（WOOD/DELICATE/POLISH）
• 优化的视觉效果

🔧 技术细节：
• 基于PIL的图片处理
• 向后兼容原有代码
• 智能回退机制
• 内存优化的图片缓存

📝 当前使用样式: {self.style_var.get()}
        """

        messagebox.showinfo("UI集成信息", info_text)

    def _on_move(self, from_pos, to_pos):
        """处理走子事件"""
        piece = self.board.get_piece(*from_pos)
        if piece:
            piece_name = piece.piece_type.value
            color = "红方" if piece.is_red else "黑方"
            self.status_label.config(
                text=f"走子: {color} {piece_name} 从 {from_pos} 到 {to_pos}"
            )

    def run(self):
        """运行应用"""
        self.root.mainloop()


def main():
    """Main function"""
    print("Starting ChineseChess AlphaZero UI Integration Test...")

    # 检查图片资源
    current_dir = os.path.dirname(os.path.abspath(__file__))
    images_dir = os.path.join(current_dir, 'assets', 'images')

    if os.path.exists(images_dir):
        print(f"Image resources directory: {images_dir}")

        # 列出可用样式
        available_styles = []
        for style in ['WOOD', 'DELICATE', 'POLISH']:
            style_dir = os.path.join(images_dir, style)
            if os.path.exists(style_dir):
                available_styles.append(style)

        if available_styles:
            print(f"Available piece styles: {', '.join(available_styles)}")
        else:
            print("Warning: No piece style directories found")
    else:
        print(f"Error: Image resources directory not found: {images_dir}")

    # 启动测试应用
    app = TestUIApp()
    app.run()


if __name__ == "__main__":
    main()