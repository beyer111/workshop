"""
测试现代化UI组件
"""
import tkinter as tk
from tkinter import ttk
from gui.control_panel import ControlPanel


class ModernUITest:
    """现代化UI测试应用"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Modern UI Test - iChess Control Panel")
        self.root.geometry("400x700")
        self.root.configure(bg='#F8F9FA')

        self._create_widgets()

    def _create_widgets(self):
        """创建测试界面"""
        # 标题
        title = tk.Label(self.root,
                        text="现代化控制面板测试",
                        bg='#F8F9FA',
                        fg='#2C3E50',
                        font=('Segoe UI', 18, 'bold'))
        title.pack(pady=20)

        # 创建现代化控制面板
        self.control_panel = ControlPanel(self.root)
        self.control_panel.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # 绑定回调函数
        self.control_panel.on_mode_change = self._on_mode_change
        self.control_panel.on_difficulty_change = self._on_difficulty_change
        self.control_panel.on_start_game = self._on_start_game
        self.control_panel.on_new_game = self._on_new_game
        self.control_panel.on_undo = self._on_undo
        self.control_panel.on_exit = self._on_exit
        self.control_panel.on_speed_mode_change = self._on_speed_mode_change

    def _on_mode_change(self, mode):
        """模式改变回调"""
        self.control_panel.update_info(f"游戏模式切换到: {mode}")

    def _on_difficulty_change(self, red_player, black_player):
        """难度改变回调"""
        self.control_panel.update_info(f"红方: {red_player}, 黑方: {black_player}")

    def _on_start_game(self):
        """开始游戏回调"""
        self.control_panel.update_info("游戏开始!")

    def _on_new_game(self):
        """新游戏回调"""
        self.control_panel.clear_info()
        self.control_panel.update_info("新游戏准备就绪")

    def _on_undo(self):
        """悔棋回调"""
        self.control_panel.update_info("悔棋操作")

    def _on_exit(self):
        """退出回调"""
        self.control_panel.update_info("准备退出游戏...")

    def _on_speed_mode_change(self, enabled):
        """加速模式切换"""
        status = "开启" if enabled else "关闭"
        self.control_panel.update_info(f"加速模式{status}")

    def run(self):
        """运行应用"""
        self.root.mainloop()


def main():
    """主函数"""
    print("Starting Modern UI Test...")
    app = ModernUITest()
    app.run()


if __name__ == "__main__":
    main()